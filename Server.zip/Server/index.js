const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

mongoose
  .connect(
    "mongodb+srv://todolist:SB43CZmyy0cUGJTn@cluster0.v1lcwdd.mongodb.net/?appName=Cluster0",
  )
  .then(() => console.log("MongoDB connected!"))
  .catch((err) => console.log("Connection error:", err));

app.listen(3001, () => {
  console.log("server is running");
});
